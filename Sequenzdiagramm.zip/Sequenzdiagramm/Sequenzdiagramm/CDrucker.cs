﻿namespace Sequenzdiagramm;

public class CDrucker
{
    public bool Aktiv { get; private set; }
    
    public bool Drucken(string dokumentName)
    {
        Random r = new Random();
        bool success = r.Next(1, 1000) > 800; // 20% success rate
        
        Console.WriteLine(dokumentName + " wird ausgedruckt...");

        if (!success)
        {
            Console.WriteLine(dokumentName + " konnte nicht ausgedruckt werden.");
        }
        else
        {
            Console.WriteLine(dokumentName + " konnte ausgedruckt werden.");
        }
        
        return success;
    }

    public void Ausschalten()
    {
        Console.WriteLine("Drucker wird ausgeschaltet...");
        this.Aktiv = false;
        Console.WriteLine("Drucker ist nun ausgeschaltet.");
    }
}