﻿using Sequenzdiagramm;

class Program
{
    static void Main(string[] args)
    {
        CDrucker drucker = new CDrucker();
        CSachbearbeiter sachbearbeiter = new CSachbearbeiter();

        bool druckOk = sachbearbeiter.Drucken(drucker);

        if (druckOk)
        {
            sachbearbeiter.Ausschalten(drucker);
        }
        else
        {
            while (!druckOk)
            {
                druckOk = sachbearbeiter.Drucken(drucker);

                if (druckOk)
                {
                    break;
                }
            }
        }
    }
}