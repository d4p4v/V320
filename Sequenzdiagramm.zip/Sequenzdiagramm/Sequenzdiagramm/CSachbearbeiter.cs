﻿namespace Sequenzdiagramm;

public class CSachbearbeiter
{
    public bool Drucken(CDrucker drucker)
    {
        bool druckOk = drucker.Drucken("dokument 1");

        return druckOk;
    }
    
    public void Ausschalten(CDrucker drucker)
    {
        drucker.Ausschalten();
    }
}